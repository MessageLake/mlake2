# mlake2
MVP

1. npm install
2. npm start
3. 127.0.0.1:3000